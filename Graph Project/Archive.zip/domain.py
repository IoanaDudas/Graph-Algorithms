class DirectedGraph:

    def __init__(self):
        self._numberVetices = 0
        self._numberEdges = 0
        self._graphIn = {}
        self._graphOut = {}
        self._graphCost = {}

    def setNumberVertices(self, numberVetices):
        self._numberVetices = numberVetices

    def getNumberVertices(self):
        return self._numberVetices

    def setNumberEdges(self, numberEdges):
        self._numberEdges = numberEdges

    def getNumberEdges(self):
        return self._numberEdges

    #def listVertices(self):

    def inDegree(self, vertex):
        degree = 0
        for each in self._graphIn[vertex]:
            degree += 1
        return degree

    def outDegree(self, vertex):
        degree = 0
        for each in self._graphOut[vertex]:
            degree += 1
        return degree

    def checkVertex(self, vertex):
        '''
        :param vertex:
            - the vertex of the graph that will be verified
        :return:
            - True, if vertex is valid
            - False, otherwise
        '''
        if vertex in self._graphIn:
            return True
        if vertex >= 0:
            return False

    def addVertex(self, vertex):
        '''
        :return:
            - True, if the vertex was successfully added
            - False, otherwise
        '''
        if vertex <= self.getNumberVertices():
            if self.checkVertex(vertex) is False:
                self._graphIn[vertex] = []
                self._graphOut[vertex] = []
                self._numberVetices += 1
                return
        else:
            raise Exception("Vertex wasn't added!")

    def removeVertex(self, vertex):
        '''
        :return:
            - True, if the edge was successfully removed
            - False, otherwise
        '''
        if self.checkVertex(vertex) is True:
            self._numberVetices -= 1
            for each in self._graphOut[vertex]:
                self._graphIn[each].remove(vertex)
                del self._graphCost[(vertex, each)]
                self._numberEdges -= 1
            del self._graphOut[vertex]
            for each in self._graphIn[vertex]:
                self._graphOut[each].remove(vertex)
            del self._graphIn[vertex]
        else:
            raise Exception("Vertex wasn't removed!")

    def checkEdge(self, firstVertex, secondVertex):
        '''
        :return:
            - True, if there exists an edge between them
            - False, otherwise
        '''
        if self.checkVertex(firstVertex) and self.checkVertex(secondVertex):
            if (firstVertex, secondVertex) in self._graphCost:
                return True
        return False

    def addEdge(self, firstVertex, secondVertex, cost):
        '''
        :return:
            - True, if the edge was successfully added
            - False, otherwise
        '''
        if self.checkEdge(firstVertex, secondVertex) is False:
            self._graphOut[firstVertex].append(secondVertex)
            self._graphIn[secondVertex].append(firstVertex)
            self._graphCost[(firstVertex, secondVertex)] = cost
            self._numberEdges += 1
        else:
            raise Exception("Edge wasn't added!")

    def removeEdge(self, firstVertex, secondVertex):
        '''
        :return:
            - True, if the edge was successfully removed
            - False, otherwise
        '''
        if self.checkEdge(firstVertex, secondVertex) is True:
            self._graphOut[firstVertex].remove(secondVertex)
            self._graphIn[secondVertex].remove(firstVertex)
            del self._graphCost[(firstVertex, secondVertex)]
            self._numberEdges -= 1
        else:
            raise Exception("Edge wasn't removed!")

    def getCost(self, firstVertex, secondVertex):
        '''
        :return:
            - the cost between the 2 vertices, if there is one
        '''
        if self.checkEdge(firstVertex, secondVertex) is True:
            return self._graphCost[(firstVertex, secondVertex)]
        else:
            raise Exception("Cost doesn't exist!")

    def setCost(self, firstVertex, secondVertex, cost):
        if self.checkEdge(firstVertex, secondVertex) is True:
            self._graphCost[(firstVertex, secondVertex)] = cost
        else:
            raise Exception("Cost wasn't updated!")

    def graphList(self):
        return self._graphOut

    def makeCopy(self):
        self._dictIn = self._graphIn
        self._dictOut = self._graphOut
        self._dictCost = self._dictCost

    def revertOriginal(self):
        self._graphIn = self._dictIn
        self._graphOut = self._dictOut
        self._graphCost = self._dictCost

    def getAllVertices(self):
        vertices = []
        for each in self._graphOut:
            vertices.append(each)
        return vertices

    def inboundEdges(self, vertex):
        inbounds = []
        for each in self._graphOut[vertex]:
            inbounds.append(each)
        return inbounds

    def outboundEdges(self, vertex):
        outbounds = []
        for each in self._graphOut[vertex]:
            outbounds.append(each)
        return outbounds